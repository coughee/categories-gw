/* 
 * File:   main.cpp
 * Author: Jonathan
 *
 * Created on 08 April 2014, 01:45
 * 
 * An unsigned long int should be big enough to store any lattice within interest
 * i.e q = 4 n = 4.
 */

#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <iostream>
#include <cstring>
#include <string>
#include <cmath>
#include <vector>
#include <string>
#include <time.h>
#include "groupCounter.h"
#include <fstream>
#include <list>
#include "matConvert.h"

//DEBUG FLAG, verbose output, -D command line.
bool debug = false;


bool checkSymmetry(matConvert mat, matConvert &mat2);
void writeMatGroup(matConvert &mat, unsigned long int group);
void buildFileNamePrefix();
bool parityCheck(std::vector<int> qList, matConvert mat, matConvert comp, matConvert ref, int cur);
bool parWrap(std::vector<int> qList, matConvert tmat, matConvert comp, matConvert ref);
using namespace std;
/*
 * 
 */
//Global Variables, sue me.
bool Z3 = true, Z2 = true, ROT = true;
int N = 0, Q = 0, B = 2;
string filePrefix;
std::vector<matConvert > symmetryList;

int main(int argc, char** argv) {
    char *outputFile;
    clock_t t;
    t = clock();
    //Command line interface.
    for (int i = 0; i < argc; i++) {
        if (std::strcmp(argv[i], "-o") == 0) {
            outputFile = argv[i + 1];
            filePrefix.append(outputFile);
            i += 1;
        }
        else if (std::strcmp(argv[i], "-N") == 0) {
            N = atoi(argv[i + 1]);
            i += 1;
        }
        else if (std::strcmp(argv[i], "-Q") == 0) {
            Q = atoi(argv[i + 1]);
            i += 1;
        }
        else if (std::strcmp(argv[i], "-Z3") == 0) {
            Z3 = false;
        }
        else if (std::strcmp(argv[i], "-Z2") == 0) {
            Z2 = false;
        }
        else if (std::strcmp(argv[i], "-R") == 0) {
            ROT = false;
        }
        else if (std::strcmp(argv[i], "-D") == 0){
            debug = true;
        }
        else if (std::strcmp(argv[i], "-B") == 0){
            B = atoi(argv[i + 1]);
            i += 1;
        }
    }
    
    buildFileNamePrefix();
    cout << filePrefix << endl;
    //Output Command line values.
    if (debug) {
        cout << "N = " << N << endl;
        cout << "Q = " << Q << endl;
        cout << "Z2 = " << Z2 << endl;
        cout << "Z3 = " << Z3 << endl;
        cout << "Rot = " << ROT << endl;
        //cout << "Output File = " << outputFile << endl;
       // cout << "WARNING: Debug mode ENABLED, verbose output" << endl;
    }

    //
    groupCounter paraCount = groupCounter();
    matConvert mat = matConvert(1,Q,N/B);
    matConvert mat2 = matConvert(1,Q,N/B);

    
    bool found;
    //Find all N/b lattices 
    for(unsigned long int i = 1; i <= pow(Q,N*N/pow(B,2.0)); i++){
        if(i % 1000 == 0){
            cout << 100*i/pow(Q,N*N/pow(B,2.0)) << endl;
        }
        found = false;
        mat.convertVal(i);
        for(unsigned long int j = 0; j < paraCount.currentGroupCount(); j++) {
            mat2.convertVal(paraCount.matValAt(j));
            for (int k = 0; k < symmetryList.size(); k++) {
                if (symmetryList[k].equalTo(mat2)) {
                    //writeMatGroup(mat, j);

                    found = true;
                    break;
                }
            }

        }
        if(found == false){
            paraCount.newGroup(i);
            //writeMatGroup(mat,paraCount.currentGroupCount() - 1);
            
        }
        
    }
    cout << "Done Calculating Groups" << endl;
    t = clock() - t;
    cout << 1000*((float)t)/((float)CLOCKS_PER_SEC) << "ms" << endl;
    return 0;
    mat = matConvert(1,Q,B);
    mat2 = matConvert(1,Q,B);
    
    //Find all bxb lattices which renormalise to q 1x1 lattices
    std::vector<std::vector< int > > qList;
    qList.resize(Q);
    
    for(unsigned long int i = 1; i <= pow(Q,B*B); i++){
        
        mat.convertVal(i);
        //writeMatGroup(mat, mat.findRN());
        qList[mat.findRN()].push_back(i);
       
        
    }
    int count = 0;

    matConvert pLattice = matConvert(1,Q,N/B);
    matConvert kVal = matConvert(1, qList[0].size(), N/B);
    matConvert renorm = matConvert(1,Q,B);
    //Generate all lattices composed from paradigm with bxb lattices. 
    matConvert pLat = matConvert(1,Q,N);
    int pLatValue;
   
    for(int paraLat = 0; paraLat < paraCount.currentGroupCount(); paraLat++){
        //Loop over all paradigm lattices;
        pLattice.convertVal(paraCount.matValAt(paraLat));
        for(unsigned long int parentCount = 1; parentCount <= pow(Q,N*N*(1 - 1/B)); parentCount++){

            //convert parentCount to base qList.size())
            kVal.convertVal(parentCount);
            for(int j = 0; j < N/B; j++){
                for(int k = 0; k < N/B - 1; k++){
                    pLatValue = pLattice.lat[j][k];
                    for(int l = 0; l < B; l++){
                        for(int m = 0; m < B; m++){
                            renorm.convertVal(qList[pLatValue][kVal.lat[j][k]]);
                            pLat.lat[j*B + l][k*B + m] = renorm.lat[l][m];
                            
                        }
                    }
                    count++;
                }
            }
        }
    }
    

    
    return 0;
}

void writeMatGroup(matConvert &mat, unsigned long int group){
    ostringstream groupss;
    groupss << group;
    groupss << ".txt";
    string tempN;
    tempN = filePrefix;
    tempN.append(groupss.str());
    std::fstream out;
    
    out.open(tempN.c_str(), std::ios::out | std::ios::app);

    for(int i = 0; i < N/B; i++){
        for(int j = 0; j < N/B; j++){
            out << mat.lat[i][j];
        }
    }
    
    out << "\n";
    out.close();
    
}



bool checkSymmetry(matConvert mat, matConvert &mat2){
    symmetryList.clear();
    matConvert temp = mat;
    for(int rotNum = 0; rotNum < 4; rotNum++){
        for(int parNum = 0; parNum < Q; parNum++){

            for (int bndNum = 0; bndNum < N; bndNum++) {
                for (int w = 0; w < N; w++) {
                    for (int oneTwo = 0; oneTwo < 2; oneTwo++) {

                        temp = mat;
                        symmetryList.push_back(temp);
                        mat.oneTwoSwitch();
                    }
                    mat.nextBoundaryY();
                }

                mat.nextBoundaryX();
            }

            mat.nextParity();

        }
        
        mat.rotate();
    }
    
    return false;
}


bool parWrap(std::vector<int> qList, matConvert tmat, matConvert comp, matConvert ref){
    for(int i = 0; i < Q; i++){
        if(parityCheck(qList, tmat, comp, ref, i)){
            return true;
        }
    }
    return false;
}

bool parityCheck(std::vector<int> qList, matConvert tmat, matConvert comp, matConvert ref, int cur){
    matConvert mat = tmat;
    std::vector<int> tList = qList;
    for(int i = 0; i < qList.size(); i++){
        tList = qList;
        mat = tmat;
        mat.exchangeSpin(qList[i], cur, ref);
        tList.erase(tList.begin() + i);
        cout << qList[i] << endl;
        //need a way to check that the number of spin exchanges is "closed"
        if(mat.countQ(ref) && mat.equalTo(comp)){
            return true;
        }
        else if(tList.size() == 0){
            return false;
        }
        else if(parityCheck(tList, mat, comp, ref, qList[i])){
            return true;
        }
    }
    return false;
}

void buildFileNamePrefix(){
    ostringstream temp;
    filePrefix.append("_N");
    temp << N;
    filePrefix.append(temp.str());
    filePrefix.append("_Q");
    temp.clear();
    temp.str("");
    temp << Q;
    filePrefix.append(temp.str());
    temp.clear();
    temp.str("");
    temp << Z3;
    filePrefix.append("_Z3");
    filePrefix.append(temp.str());
    temp.clear();
    temp.str("");
    temp << Z2;
    filePrefix.append("_Z2");
    filePrefix.append(temp.str());
    temp.clear();
    temp.str("");
    temp << ROT;
    filePrefix.append("_ROT");
    filePrefix.append(temp.str());
    temp.clear();
    temp.str("_GROUP_");
    filePrefix.append(temp.str());
}

